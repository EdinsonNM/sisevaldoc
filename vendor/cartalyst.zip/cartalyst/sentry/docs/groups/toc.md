## Groups


- [Create a Group]({url}/groups/create)
- [Update a Group]({url}/groups/update)
- [Delete a Group]({url}/groups/delete)
- [Find Groups]({url}/groups/find)
    - [Find All Groups](#find-all-the-groups)
    - [Find a Group by Id](#find-a-group-by-its-id)
    - [Find a Group by Name](#find-a-group-by-its-name)
- [Helpers]({url}/groups/helpers)
    - [getPermissions()](#getpermissions)
