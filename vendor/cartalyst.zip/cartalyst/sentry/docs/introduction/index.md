## Introduction

Sentry is a simple, powerful and easy to use authorization and authentication package. It provides additional features such as groups, permissions, custom hashing algorithms and additional security features.
