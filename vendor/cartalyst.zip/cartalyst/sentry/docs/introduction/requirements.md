## Requirements {#requirements}

Like most of our packages sentry has the same requirements as Laravel 4. Since Sentry is framework agnostic the following is required.

---

- PHP >= 5.3.7
- MCrypt PHP Extension
