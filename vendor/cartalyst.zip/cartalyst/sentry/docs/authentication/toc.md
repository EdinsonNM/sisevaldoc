## Authentication

- [Authenticate a User]({url}/authentication)
- [Logs a User In]({url}/authentication/login)
- [Logs a User Out]({url}/authentication/logout)
- [Helpers]({url}/authentication/helpers)
