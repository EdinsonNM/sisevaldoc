## Install & Configure

- [Composer]({url}/installation/composer)
- [Laravel 4]({url}/installation/laravel-4)
- [FuelPHP 1.x]({url}/installation/fuelphp-1)
- [CodeIgniter 3.0-dev]({url}/installation/codeigniter-3)
