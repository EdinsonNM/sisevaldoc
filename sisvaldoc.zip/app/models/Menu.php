<?php
class Menu extends Eloquent {
   protected $table = 'menu';

}
?>